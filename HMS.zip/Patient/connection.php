<?php
$conn = mysqli_connect("localhost", "root", "shrey123", "id15191429_hms");
?>
