<?php

$available = $_POST["doctor_id"];

// Doctor timesolt Query

$timeslots = array(
	"s1" => "10:00am - 11:00am",
	"s2" => "11:00am - 12:00pm"
	"s3" => "12:00pm - 1:00pm"
	"s4" => "1:00pm - 2:00pm"
	"s5" => "2:00pm - 3:00pm"
	"s6" => "3:00pm - 4:00pm"
	"s7" => "4:00pm - 5:00pm"
);




?>